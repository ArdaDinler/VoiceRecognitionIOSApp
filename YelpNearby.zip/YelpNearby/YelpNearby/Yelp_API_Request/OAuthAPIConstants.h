//
//  OAuthAPIConstants.h
//  YelpNearby
//
//  Created by Behera, Subhransu on 8/14/13.
//  Copyright (c) 2013 Behera, Subhransu. All rights reserved.
//

#ifndef YelpNearby_OAuthAPIConstants_h
#define YelpNearby_OAuthAPIConstants_h

#define OAUTH_CONSUMER_KEY @"Ya_hBzILxDc8dO16XbuWTQ"
#define OAUTH_CONSUMER_SECRET @"VBsqEiK-gjkNvH2O83BAgjJSyYE"
#define OAUTH_TOKEN @"9MZoW4x85KEy0Ttx0pMW65Oh3dGbcm65"
#define OAUTH_TOKEN_SECRET @"yO99D_E7pkO1fqkQn4GxIzdjga8"
#define YELP_SEARCH_URL @"http://api.yelp.com/v2/search"

#endif
